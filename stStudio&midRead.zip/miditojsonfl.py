import mido
from mido import MidiFile
import json
import os
from datetime import datetime
midi_file_path = "/storage/emulated/0/Download/Cogwork_Dancers.mid"
column_count = 32

def note_number_to_row(note_number):
    """
    Конвертирует номер MIDI ноты в строку сетки (0-48)
    Возвращает None если нота вне диапазона
    """
    # Диапазон нот в вашем редакторе: от C2 (36) до G6 (91)
    if 36 <= note_number <= 91:
        return note_number - 36
    return None

def parse_midi_to_json(midi_filename, output_filename=None, column_count=16):
    """Парсит MIDI-файл и сохраняет в JSON формате для редактора"""
    
    try:
        # Загружаем MIDI файл
        mid = MidiFile(midi_filename)
        
        # Настройки по умолчанию
        bpm = 120
        tempo = 500000  # стандартный темп (микросекунды на четверть ноту)
        ticks_per_beat = mid.ticks_per_beat
        
        # Получаем BPM из MIDI файла
        for track in mid.tracks:
            for msg in track:
                if msg.type == 'set_tempo':
                    tempo = msg.tempo
                    bpm = 60000000 / tempo  # вычисляем BPM
        
        # Собираем все ноты
        all_notes = []
        max_time_ticks = 0
        
        for track in mid.tracks:
            current_time_ticks = 0
            
            for msg in track:
                current_time_ticks += msg.time
                
                if msg.type == 'note_on' and msg.velocity > 0:
                    # Конвертируем время из тиков в шаги (предполагаем 16 шагов на такт)
                    time_in_seconds = mido.tick2second(current_time_ticks, ticks_per_beat, tempo)
                    steps = int(time_in_seconds * (bpm / 60) * 4)  # 4 шага на четверть ноту
                    
                    # Конвертируем номер ноты в строку сетки
                    row = note_number_to_row(msg.note)
                    
                    if row is not None:  # Игнорируем ноты вне диапазона
                        all_notes.append({
                            'row': row,
                            'step': steps,
                            'channel': msg.channel
                        })
                        
                        # Обновляем максимальное время
                        max_time_ticks = max(max_time_ticks, current_time_ticks)
        
        # Находим максимальное количество шагов
        max_steps = 0
        for note in all_notes:
            max_steps = max(max_steps, note['step'])
        
        # Если нет нот, создаем пустой паттерн
        if max_steps == 0:
            max_steps = column_count - 1
        
        # Разделяем ноты по паттернам
        patterns = []
        total_patterns = (max_steps // column_count) + 1
        
        for pattern_index in range(total_patterns):
            start_step = pattern_index * column_count
            end_step = start_step + column_count - 1
            
            # Собираем ноты для этого паттерна
            pattern_notes = {}
            
            for note in all_notes:
                if start_step <= note['step'] <= end_step:
                    # Пересчитываем шаг относительно начала паттерна
                    local_step = note['step'] - start_step
                    instrument = note['channel'] % 15+1  # Ограничиваем 15 инструментами (0-14)
                    
                    if instrument not in pattern_notes:
                        pattern_notes[instrument] = []
                    
                    pattern_notes[instrument].append(f"{note['row']},{local_step}")
            
            # Добавляем паттерн, только если в нем есть ноты
            if pattern_notes:
                pattern_name = f"{os.path.basename(midi_filename).replace('.mid', '').replace('.MID', '')} - Part {pattern_index + 1}"
                
                patterns.append({
                    "name": pattern_name,
                    "cols": column_count,
                    "notes": pattern_notes
                })
        
        # Если нет паттернов с нотами, создаем один пустой
        if not patterns:
            patterns.append({
                "name": os.path.basename(midi_filename).replace('.mid', '').replace('.MID', ''),
                "cols": column_count,
                "notes": {}
            })
        
        # Создаем структуру данных для JSON
        data = {
            "version": "compact_v3",
            "created": datetime.now().isoformat(),
            "bpm": int(bpm),
            "current_instrument": 0,
            "current_pattern_index": 0,
            "grid_settings": {
                "rows": 49,
                "cell_width": 40,
                "cell_height": 20,
                "grid_cols": column_count
            },
            "patterns": patterns
        }
        
        # Сохраняем в файл
        if output_filename is None:
            output_filename = midi_filename.replace('.mid', '.json').replace('.MID', '.json')
        
        with open(output_filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        print(f"Успешно конвертировано: {midi_filename} -> {output_filename}")
        print(f"BPM: {bpm:.0f}, Всего шагов: {max_steps + 1}, Нот: {len(all_notes)}")
        print(f"Создано паттернов: {len(patterns)} по {column_count} столбцов")
        
        return data
        
    except Exception as e:
        print(f"Ошибка при конвертации {midi_filename}: {e}")
        return None

# УКАЖИТЕ ПУТЬ К ВАШЕМУ MIDI ФАЙЛУ ЗДЕСЬ


# УКАЖИТЕ КОЛИЧЕСТВО СТОЛБЦОВ В ПАТТЕРНЕ (8, 16, 32 и т.д.)


if __name__ == "__main__":
    if os.path.exists(midi_file_path):
        print(f"Конвертация файла: {midi_file_path}")
        print(f"Количество столбцов в паттерне: {column_count}")
        result = parse_midi_to_json(midi_file_path, column_count=column_count)
        if result:
            print("Конвертация завершена успешно!")
        else:
            print("Конвертация не удалась!")
    else:
        print(f"Файл не найден: {midi_file_path}")
        print("Пожалуйста, проверьте путь к файлу")