import pygame
import json
import os
import numpy as np
from scipy.io import wavfile
import sys
import math
import array
import random
from scipy import signal


work_path="/storage/emulated/0/mus"



pygame.init()
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Music Player & Converter")

BACKGROUND = (25, 25, 35)
TEXT_COLOR = (220, 220, 220)
BUTTON_COLOR = (70, 100, 150)
BUTTON_HOVER = (90, 130, 180)
LIST_COLOR = (40, 40, 55)
LIST_HOVER = (60, 60, 80)
LIST_SELECTED = (0, 150, 200)
SCROLLBAR_COLOR = (80, 80, 100)

SAMPLE_RATE = 44100
VOLUME = 0.3

def create_notes():
    notes = []
    note_names = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
    base_freq = 65.41
    for octave in range(2, 7):
        for i, note_name in enumerate(note_names):
            if octave == 6 and i > 9:
                break
            freq = base_freq * (2 ** ((octave - 2) + i / 12))
            notes.append((f"{note_name}{octave}", freq))
    return notes

NOTES = create_notes()

def generate_wave(freq, duration, sample_rate, wave_type, volume=1.0):
    n_samples = int(sample_rate * duration)
    samples = array.array('h', (0 for _ in range(n_samples)))
    max_amp = 2 ** 15 - 1
    
    for i in range(n_samples):
        t = i / sample_rate
        envelope = 1.0
        
        if wave_type == "piano":
            wave = 0.5 * math.sin(2 * math.pi * freq * t)
            wave += 0.3 * math.sin(2 * math.pi * 2 * freq * t) * math.exp(-2 * t)
            wave += 0.2 * math.sin(2 * math.pi * 3 * freq * t) * math.exp(-3 * t)
            wave += 0.1 * math.sin(2 * math.pi * 4 * freq * t) * math.exp(-4 * t)
            attack_noise = 0.1 * (2 * random.random() - 1) * math.exp(-15 * t)
            wave += attack_noise
            envelope = 1.0
            
        elif wave_type == "guitar":
            wave = 0.6 * math.sin(2 * math.pi * freq * t)
            wave += 0.3 * math.sin(2 * math.pi * freq * 1.01 * t)
            wave += 0.4 * math.sin(2 * math.pi * 2 * freq * t) * math.exp(-1.5 * t)
            wave += 0.2 * math.sin(2 * math.pi * 3 * freq * t) * math.exp(-2 * t)
            envelope = math.exp(-1.2 * t)
            
        elif wave_type == "violin":
            wave = 0.4 * math.sin(2 * math.pi * freq * t)
            wave += 0.3 * math.sin(2 * math.pi * 2 * freq * t)
            wave += 0.2 * math.sin(2 * math.pi * 3 * freq * t)
            wave += 0.1 * math.sin(2 * math.pi * 4 * freq * t)
            wave += 0.05 * math.sin(2 * math.pi * 5 * freq * t)
            vibrato = 0.01 * math.sin(2 * math.pi * 5 * t)
            wave *= (1 + vibrato)
            envelope = 1.0
            
        elif wave_type == "trumpet":
            wave = 0.5 * math.sin(2 * math.pi * freq * t)
            wave += 0.4 * math.sin(2 * math.pi * 2 * freq * t)
            wave += 0.3 * math.sin(2 * math.pi * 3 * freq * t)
            wave += 0.1 * math.sin(2 * math.pi * 4 * freq * t)
            envelope = 1 - math.exp(-20 * t)
            
        elif wave_type == "flute":
            wave = 0.8 * math.sin(2 * math.pi * freq * t)
            wave += 0.2 * math.sin(2 * math.pi * 2 * freq * t)
            envelope = 1 - math.exp(-5 * t)
            vibrato = 0.005 * math.sin(2 * math.pi * 6 * t)
            wave *= (1 + vibrato)
            
        elif wave_type == "bass":
            wave = 1 if math.sin(2 * math.pi * freq * t) > 0 else -1
            envelope = 1.0 - min(1.0, t / duration)
        else:
            wave = math.sin(2 * math.pi * freq * t)
            envelope = min(1.0, t * 2) * (1.0 - min(1.0, max(0, t - duration + 0.1) * 5))
            
        samples[i] = int(wave * envelope * max_amp * volume * 0.3)
    return samples

def generate_drum_sound(drum_type, duration=0.5, sample_rate=44100, volume=1.0):
    n_samples = int(sample_rate * duration)
    t = np.linspace(0, duration, n_samples, False)
    
    if drum_type == "kick":
        freq_sweep = np.linspace(150, 50, n_samples)
        wave = np.sin(2 * np.pi * freq_sweep * t)
        envelope = np.exp(-12 * t)
        wave *= envelope
        
    elif drum_type == "snare":
        tone = np.sin(2 * np.pi * 180 * t) * np.exp(-15 * t)
        noise = np.random.normal(0, 1, n_samples)
        noise_envelope = np.exp(-20 * t)
        noise *= noise_envelope
        wave = 0.7 * noise + 0.3 * tone
        
    elif drum_type == "hihat":
        noise = np.random.normal(0, 1, n_samples)
        b, a = signal.butter(4, [5000, 12000], 'bandpass', fs=sample_rate)
        noise = signal.lfilter(b, a, noise)
        envelope = np.exp(-50 * t)
        wave = noise * envelope
        
    elif drum_type == "tom":
        freq_sweep = np.linspace(200, 100, n_samples)
        wave = np.sin(2 * np.pi * freq_sweep * t)
        envelope = np.exp(-8 * t)
        wave *= envelope
        
    elif drum_type == "clap":
        noise = np.random.normal(0, 1, n_samples)
        envelope = np.zeros_like(t)
        for i in range(3):
            start = i * 0.02
            env_part = np.exp(-80 * (t - start))
            env_part[t < start] = 0
            envelope += env_part
        wave = noise * envelope
        
    else:
        wave = np.random.normal(0, 1, n_samples) * np.exp(-10 * t)
    
    if np.max(np.abs(wave)) > 0:
        wave = wave / np.max(np.abs(wave))
    
    samples = array.array('h', (0 for _ in range(n_samples)))
    max_amp = 2 ** 15 - 1
    for i in range(n_samples):
        samples[i] = int(wave[i] * max_amp * volume)
    
    return samples

INSTRUMENTS = ["Пианино", "Гитара", "Скрипка", "Синт-лид", "Бас", "Пэд", "Белл", "Плак",
               "Труба", "Флейта", "Бас-барабан", "Малый барабан", "Хай-хэт", "Том-том", "Хлопок"]

SOUND_GENERATORS = [
    lambda f, d, sr, v=1.0: generate_wave(f, d, sr, "piano", v),
    lambda f, d, sr, v=1.0: generate_wave(f, d, sr, "guitar", v),
    lambda f, d, sr, v=1.0: generate_wave(f, d, sr, "violin", v),
    lambda f, d, sr, v=1.0: generate_wave(f, d, sr, "synth_lead", v),
    lambda f, d, sr, v=1.0: generate_wave(f, d, sr, "bass", v),
    lambda f, d, sr, v=1.0: generate_wave(f, d, sr, "pad", v),
    lambda f, d, sr, v=1.0: generate_wave(f, d, sr, "bell", v),
    lambda f, d, sr, v=1.0: generate_wave(f, d, sr, "pluck", v),
    lambda f, d, sr, v=1.0: generate_wave(f, d, sr, "trumpet", v),
    lambda f, d, sr, v=1.0: generate_wave(f, d, sr, "flute", v),
    lambda f, d, sr, v=1.0: generate_drum_sound("kick", d, sr, v),
    lambda f, d, sr, v=1.0: generate_drum_sound("snare", d, sr, v),
    lambda f, d, sr, v=1.0: generate_drum_sound("hihat", d, sr, v),
    lambda f, d, sr, v=1.0: generate_drum_sound("tom", d, sr, v),
    lambda f, d, sr, v=1.0: generate_drum_sound("clap", d, sr, v)
]

class MusicPlayer:
    def __init__(self):
        self.music_folder = work_path
        if not os.path.exists(self.music_folder):
            self.music_folder = "./saved_patterns"
            os.makedirs(self.music_folder, exist_ok=True)
        
        self.songs = []
        self.selected_index = 0
        self.scroll_offset = 0
        self.visible_items = 8  
        self.load_songs()
        
        try:
            pygame.mixer.init(frequency=SAMPLE_RATE, size=-16, channels=2, buffer=512)
            self.audio_enabled = True
        except:
            self.audio_enabled = False
    
    def load_songs(self):
        
        self.songs = []
        if os.path.exists(self.music_folder):
            for file in os.listdir(self.music_folder):
                if file.endswith('.json'):
                    self.songs.append(file)
        self.songs.sort()
    
    def load_song_data(self, filename):
        filepath = os.path.join(self.music_folder, filename)
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"Ошибка загрузки: {e}")
            return None
    
    def calculate_total_duration(self, data):
        if not data:
            return 0
        
        bpm = data.get("bpm", 120)
        patterns = data.get("patterns", [])
        
        steps_per_beat = 4 
        step_duration = 60.0 / bpm / steps_per_beat
        
        total_steps = 0
        for pattern in patterns:
            cols = pattern.get("cols", 16)
            total_steps += cols
        
        total_duration = total_steps * step_duration
        return total_duration
    
    def generate_song_audio(self, data):
        if not data:
            return None
        
        bpm = data.get("bpm", 120)
        patterns = data.get("patterns", [])
        
        steps_per_beat = 4
        step_duration = 60.0 / bpm / steps_per_beat
        
        total_steps = 0
        for pattern in patterns:
            cols = pattern.get("cols", 16)
            total_steps += cols
        
        total_duration = total_steps * step_duration
        total_samples = int(total_duration * SAMPLE_RATE)
        
        mono_audio = np.zeros(total_samples, dtype=np.float32)
        
        current_sample = 0
        
        for pattern in patterns:
            pattern_cols = pattern.get("cols", 16)
            pattern_duration = pattern_cols * step_duration
            pattern_samples = int(pattern_duration * SAMPLE_RATE)
            
            pattern_audio = np.zeros(pattern_samples, dtype=np.float32)
            
            for instrument_id, notes_list in pattern.get("notes", {}).items():
                for note_str in notes_list:
                    try:
                        row, col = map(int, note_str.split(","))
                        instrument_id = int(instrument_id)
                        
                        if (instrument_id < 0 or instrument_id >= len(SOUND_GENERATORS) or 
                            row < 0 or row >= len(NOTES)):
                            continue
                        
                        note_start_time = col * step_duration
                        note_start_sample = int(note_start_time * SAMPLE_RATE)
                        
                        freq = NOTES[row][1]
                        
                        note_samples = SOUND_GENERATORS[instrument_id](freq, step_duration, SAMPLE_RATE, VOLUME)
                        np_note_samples = np.array(note_samples, dtype=np.float32) / 32767.0
                        
                        end_sample = min(note_start_sample + len(np_note_samples), pattern_samples)
                        note_length = end_sample - note_start_sample
                        
                        if note_length > 0:
                            pattern_audio[note_start_sample:end_sample] += np_note_samples[:note_length]
                            
                    except Exception as e:
                        print(f"Ошибка обработки ноты: {e}")
                        continue
            
            end_sample = min(current_sample + pattern_samples, total_samples)
            pattern_length = end_sample - current_sample
            
            if pattern_length > 0:
                mono_audio[current_sample:end_sample] += pattern_audio[:pattern_length]
            
            current_sample += pattern_samples
        
        if np.max(np.abs(mono_audio)) > 0:
            mono_audio = mono_audio / np.max(np.abs(mono_audio))
        stereo_audio = np.column_stack((mono_audio, mono_audio))
        
        return stereo_audio
    
    def play_song(self, filename):
        if not self.audio_enabled:
            print("Аудио не инициализировано")
            return None
        
        data = self.load_song_data(filename)
        if not data:
            print("Не удалось загрузить данные песни")
            return None
        
        duration = self.calculate_total_duration(data)
        print(f"Длительность композиции: {duration:.2f} секунд")
        
        stereo_audio = self.generate_song_audio(data)
        if stereo_audio is None:
            print("Не удалось сгенерировать аудио")
            return None
        
        sound_array = (stereo_audio * 32767).astype(np.int16)
        
        try:
            sound = pygame.sndarray.make_sound(sound_array)
            sound.play()
            return sound
        except Exception as e:
            print(f"Ошибка воспроизведения: {e}")
            return None
    
    def convert_to_wav(self, filename):
        data = self.load_song_data(filename)
        if not data:
            return False
        
        duration = self.calculate_total_duration(data)
        print(f"Конвертация: {filename}, длительность: {duration:.2f} секунд")
        
        stereo_audio = self.generate_song_audio(data)
        if stereo_audio is None:
            return False
        
        sound_array = (stereo_audio * 32767).astype(np.int16)
        
        wav_filename = filename.replace('.json', '.wav')
        wav_path = os.path.join(self.music_folder, wav_filename)
        
        try:
            wavfile.write(wav_path, SAMPLE_RATE, sound_array)
            print(f"Успешно конвертировано: {wav_filename}")
            return True
        except Exception as e:
            print(f"Ошибка сохранения WAV: {e}")
            return False

    def draw(self, screen):
        screen.fill(BACKGROUND)
        
        font_large = pygame.font.SysFont(None, 36)
        title = font_large.render("Music Player & Converter", True, TEXT_COLOR)
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 20))
        
        list_rect = pygame.Rect(50, 80, WIDTH - 150, HEIGHT - 200)
        pygame.draw.rect(screen, LIST_COLOR, list_rect, border_radius=8)
        pygame.draw.rect(screen, TEXT_COLOR, list_rect, 2, border_radius=8)
        
        font_medium = pygame.font.SysFont(None, 24)
        list_title = font_medium.render("Available Songs:", True, TEXT_COLOR)
        screen.blit(list_title, (list_rect.x + 10, list_rect.y - 30))
        
        up_button_rect = pygame.Rect(list_rect.right + 10, list_rect.y, 60, 40)
        down_button_rect = pygame.Rect(list_rect.right + 10, list_rect.bottom - 40, 60, 40)
        
        up_color = BUTTON_HOVER if up_button_rect.collidepoint(pygame.mouse.get_pos()) else BUTTON_COLOR
        pygame.draw.rect(screen, up_color, up_button_rect, border_radius=5)
        pygame.draw.rect(screen, TEXT_COLOR, up_button_rect, 2, border_radius=5)
        up_text = font_medium.render("↑", True, TEXT_COLOR)
        screen.blit(up_text, (up_button_rect.centerx - up_text.get_width() // 2, up_button_rect.centery - up_text.get_height() // 2))
        
        down_color = BUTTON_HOVER if down_button_rect.collidepoint(pygame.mouse.get_pos()) else BUTTON_COLOR
        pygame.draw.rect(screen, down_color, down_button_rect, border_radius=5)
        pygame.draw.rect(screen, TEXT_COLOR, down_button_rect, 2, border_radius=5)
        down_text = font_medium.render("↓", True, TEXT_COLOR)
        screen.blit(down_text, (down_button_rect.centerx - down_text.get_width() // 2, down_button_rect.centery - down_text.get_height() // 2))
        
        item_height = 40
        start_index = self.scroll_offset
        end_index = min(start_index + self.visible_items, len(self.songs))
        
        for i in range(start_index, end_index):
            item_rect = pygame.Rect(
                list_rect.x + 10,
                list_rect.y + 10 + (i - start_index) * item_height,
                list_rect.width - 20,
                item_height - 5
            )
            
            color = LIST_SELECTED if i == self.selected_index else LIST_COLOR
            if item_rect.collidepoint(pygame.mouse.get_pos()):
                color = LIST_HOVER
            
            pygame.draw.rect(screen, color, item_rect, border_radius=5)
            
            font_small = pygame.font.SysFont(None, 20)
            song_text = font_small.render(self.songs[i], True, TEXT_COLOR)
            screen.blit(song_text, (item_rect.x + 10, item_rect.y + item_rect.height // 2 - song_text.get_height() // 2))
        
        button_width = 200
        button_height = 50
        button_y = HEIGHT - 80
        
        play_rect = pygame.Rect(WIDTH // 2 - button_width - 20, button_y, button_width, button_height)
        play_color = BUTTON_HOVER if play_rect.collidepoint(pygame.mouse.get_pos()) else BUTTON_COLOR
        pygame.draw.rect(screen, play_color, play_rect, border_radius=8)
        pygame.draw.rect(screen, TEXT_COLOR, play_rect, 2, border_radius=8)
        play_text = font_medium.render("Play Selected", True, TEXT_COLOR)
        screen.blit(play_text, (play_rect.centerx - play_text.get_width() // 2, play_rect.centery - play_text.get_height() // 2))
        
        convert_rect = pygame.Rect(WIDTH // 2 + 20, button_y, button_width, button_height)
        convert_color = BUTTON_HOVER if convert_rect.collidepoint(pygame.mouse.get_pos()) else BUTTON_COLOR
        pygame.draw.rect(screen, convert_color, convert_rect, border_radius=8)
        pygame.draw.rect(screen, TEXT_COLOR, convert_rect, 2, border_radius=8)
        convert_text = font_medium.render("Convert to WAV", True, TEXT_COLOR)
        screen.blit(convert_text, (convert_rect.centerx - convert_text.get_width() // 2, convert_rect.centery - convert_text.get_height() // 2))
        
        info_font = pygame.font.SysFont(None, 18)
        if self.songs:
            info_text = f"Selected: {self.songs[self.selected_index]} | Songs: {len(self.songs)}"
        else:
            info_text = "No songs available"
        info_surface = info_font.render(info_text, True, TEXT_COLOR)
        screen.blit(info_surface, (WIDTH // 2 - info_surface.get_width() // 2, HEIGHT - 120))
        
        return up_button_rect, down_button_rect, play_rect, convert_rect, list_rect

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1: 
                    mouse_pos = pygame.mouse.get_pos()
                    up_rect, down_rect, play_rect, convert_rect, list_rect = self.draw(screen)
                    
                    if up_rect.collidepoint(mouse_pos) and self.songs:
                        if self.selected_index > 0:
                            self.selected_index -= 1
                            if self.selected_index < self.scroll_offset:
                                self.scroll_offset = self.selected_index
                    
                    if down_rect.collidepoint(mouse_pos) and self.songs:
                        if self.selected_index < len(self.songs) - 1:
                            self.selected_index += 1
                            if self.selected_index >= self.scroll_offset + self.visible_items:
                                self.scroll_offset = self.selected_index - self.visible_items + 1
                    
                    if list_rect.collidepoint(mouse_pos):
                        item_height = 40
                        rel_y = mouse_pos[1] - list_rect.y - 10
                        item_index = self.scroll_offset + rel_y // item_height
                        
                        if 0 <= item_index < len(self.songs) and item_index < self.scroll_offset + self.visible_items:
                            self.selected_index = item_index
                    
                    
                    if play_rect.collidepoint(mouse_pos) and self.songs:
                        current_song = self.songs[self.selected_index]
                        print(f"Воспроизведение: {current_song}")
                        self.play_song(current_song)
                    
                    # Кнопка конвертации
                    if convert_rect.collidepoint(mouse_pos) and self.songs:
                        current_song = self.songs[self.selected_index]
                        print(f"Конвертация: {current_song}")
                        if self.convert_to_wav(current_song):
                            print("Успешно!")
                        else:
                            print("Ошибка конвертации!")
        
        return True

def main():
    player = MusicPlayer()
    clock = pygame.time.Clock()
    running = True
    
    while running:
        running = player.handle_events()
        player.draw(screen)
        pygame.display.flip()
        clock.tick(60)
    
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()