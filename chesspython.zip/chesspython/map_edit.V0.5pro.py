#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import pygame
import sys
import json
import os
from enum import Enum
from typing import Set, List, Tuple, Optional

pygame.init()

# Constants
CELL_SIZE = 60
MARGIN = 50
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BROWN1 = (240, 217, 181)
BROWN2 = (181, 136, 99)
BLUE = (0, 100, 200)
RED = (200, 0, 0)
GREEN = (0, 200, 0)
GRAY = (64, 64, 64)
LIGHT_GRAY = (200, 200, 200)
GOLD = (255, 215, 0)
PURPLE = (150, 100, 200)
LIGHT_BLUE = (100, 100, 255)
PLATFORM_COLOR = (139, 69, 19)

# UI Constants - увеличена высота для лучшего размещения
UI_PANEL_HEIGHT = 200
BUTTON_HEIGHT = 30
BUTTON_MARGIN = 10  # Увеличили отступы

class PieceType(Enum):
    KING = "K"
    QUEEN = "Q" 
    ROOK = "R"
    BISHOP = "B"
    KNIGHT = "N"
    PAWN = "P"

class Player(Enum):
    PLAYER = "player"
    ENEMY = "enemy"

class DisplayMode(Enum):
    LETTERS = "letters"
    IMAGES = "images" 
    UNICODE = "unicode"

class EditorTool(Enum):
    BLOCK = "block"
    PLATFORM = "platform"
    PLAYER_PIECE = "player_piece"
    ENEMY_PIECE = "enemy_piece"
    ERASER = "eraser"

class Piece:
    def __init__(self, piece_type: PieceType, player: Player, x: int, y: int):
        self.type = piece_type
        self.player = player
        self.x = x
        self.y = y

class MapEditor:
    def __init__(self):
        self.width = 8
        self.height = 8
        self.pieces: List[Piece] = []
        self.blocks: Set[Tuple[int, int]] = set()
        self.platforms: Set[Tuple[int, int]] = set()
        self.current_tool = EditorTool.BLOCK
        self.current_piece_type = PieceType.PAWN
        self.current_category = "users"
        self.current_filename = None
        
        # Режим отображения и текстуры
        self.display_mode = DisplayMode.LETTERS
        self.piece_images = {}
        self.images_loaded = False
        self.load_piece_images()
        
        if self.images_loaded:
            self.display_mode = DisplayMode.IMAGES
        
        self.CELL_SIZE = CELL_SIZE
        self.MARGIN = MARGIN
        
        self.board_width = self.width * CELL_SIZE + 2 * MARGIN
        self.board_height = self.height * CELL_SIZE + 2 * MARGIN
        self.screen_width = max(1100, self.board_width)  # Увеличили минимальную ширину
        self.screen_height = self.board_height + UI_PANEL_HEIGHT
        
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        pygame.display.set_caption("Gravity Chess - Map Editor")
        
        self.font = pygame.font.Font(None, 24)
        self.small_font = pygame.font.Font(None, 20)
        self.title_font = pygame.font.Font(None, 32)
        
        self.create_ui_buttons()
        
    def load_piece_images(self):
        """Загружает текстуры фигур как в основной игре"""
        base_path = "/storage/emulated/0/chesspython/chess_images"
        piece_files = {
            'king_white': 'king_blue.jpg', 'queen_white': 'queen_blue.jpg', 'rook_white': 'rook_blue.jpg',
            'bishop_white': 'bishop_blue.jpg', 'knight_white': 'knight_blue.jpg', 'pawn_white': 'pawn_blue.jpg',
            'king_black': 'king_red.jpg', 'queen_black': 'queen_red.jpg', 'rook_black': 'rook_red.jpg',
            'bishop_black': 'bishop_red.jpg', 'knight_black': 'knight_red.jpg', 'pawn_black': 'pawn_red.jpg'
        }
        
        try:
            if not os.path.exists(base_path):
                self.images_loaded = False
                return
            
            missing_files = []
            for file in piece_files.values():
                file_path = os.path.join(base_path, file)
                if not os.path.exists(file_path):
                    missing_files.append(file)
            
            if missing_files:
                self.images_loaded = False
                return
            
            loaded_count = 0
            for name, file in piece_files.items():
                try:
                    file_path = os.path.join(base_path, file)
                    img = pygame.image.load(file_path)
                    self.piece_images[name] = pygame.transform.scale(img, (CELL_SIZE-10, CELL_SIZE-10))
                    loaded_count += 1
                except Exception:
                    continue
            
            self.images_loaded = (loaded_count == len(piece_files))
            
        except Exception:
            self.images_loaded = False
    
    def get_available_levels(self, category: str) -> List[str]:
        """Получает список доступных уровней в категории"""
        base_path = "/storage/emulated/0/chesspython/levels"
        category_path = f"{base_path}/{category}"
        
        levels = []
        if os.path.exists(category_path):
            for file in os.listdir(category_path):
                if file.endswith('.json'):
                    levels.append(file)
        
        # Также проверяем внутреннее хранилище
        internal_path = f"/data/data/ru.iiec.pydroid3/files/levels/{category}"
        if os.path.exists(internal_path):
            for file in os.listdir(internal_path):
                if file.endswith('.json') and file not in levels:
                    levels.append(file)
        
        return sorted(levels)
    
    def generate_unique_filename(self, base_name: str, category: str) -> str:
        """Генерирует уникальное имя файла, добавляя цифру если нужно"""
        base_path = "/storage/emulated/0/chesspython/levels"
        category_path = f"{base_path}/{category}"
        
        # Проверяем внешнее хранилище
        if os.path.exists(category_path):
            existing_files = [f for f in os.listdir(category_path) if f.endswith('.json')]
        else:
            existing_files = []
        
        # Проверяем внутреннее хранилище
        internal_path = f"/data/data/ru.iiec.pydroid3/files/levels/{category}"
        if os.path.exists(internal_path):
            internal_files = [f for f in os.listdir(internal_path) if f.endswith('.json')]
            existing_files.extend([f for f in internal_files if f not in existing_files])
        
        # Если базовое имя свободно, используем его
        if f"{base_name}.json" not in existing_files:
            return f"{base_name}.json"
        
        # Ищем свободное имя с цифрой
        counter = 1
        while True:
            new_name = f"{base_name}_{counter}.json"
            if new_name not in existing_files:
                return new_name
            counter += 1
    
    def show_level_selection(self):
        """Показывает диалог выбора уровня для редактирования с выбором категории"""
        # Создаем окно выбора
        selection_width = 700
        selection_height = 500
        selection_screen = pygame.display.set_mode((selection_width, selection_height))
        pygame.display.set_caption("Выберите уровень для редактирования")
        
        # Кнопки выбора категории
        category_buttons = [
            ("users", "Пользовательские уровни", pygame.Rect(100, 50, 500, 40)),
            ("main", "Основная компания", pygame.Rect(100, 100, 500, 40)),
            ("cancel", "Отмена", pygame.Rect(100, 150, 500, 40))
        ]
        
        level_buttons = []
        scroll_offset = 0
        selected_category = self.current_category
        levels = self.get_available_levels(selected_category)
        
        # Создаем кнопки уровней
        for i, level in enumerate(levels):
            rect = pygame.Rect(100, 200 + i * 40 - scroll_offset, 500, 35)
            level_buttons.append((level, rect))
        
        max_scroll = max(0, len(levels) * 40 - 250)
        
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return None
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:  # Левая кнопка
                        pos = pygame.mouse.get_pos()
                        
                        # Проверяем кнопки категорий
                        for category, name, rect in category_buttons:
                            if rect.collidepoint(pos):
                                if category == "cancel":
                                    return None
                                elif category in ["users", "main"]:
                                    selected_category = category
                                    levels = self.get_available_levels(selected_category)
                                    level_buttons = []
                                    for i, level in enumerate(levels):
                                        rect = pygame.Rect(100, 200 + i * 40 - scroll_offset, 500, 35)
                                        level_buttons.append((level, rect))
                                    max_scroll = max(0, len(levels) * 40 - 250)
                        
                        # Проверяем кнопки уровней
                        for level, rect in level_buttons:
                            if rect.collidepoint(pos):
                                self.current_category = selected_category
                                return level
                    
                    # Прокрутка
                    elif event.button == 4:  # Прокрутка вверх
                        scroll_offset = max(0, scroll_offset - 30)
                    elif event.button == 5:  # Прокрутка вниз
                        scroll_offset = min(max_scroll, scroll_offset + 30)
                elif event.type == pygame.MOUSEWHEEL:
                    scroll_offset = max(0, min(max_scroll, scroll_offset - event.y * 30))
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        return None
            
            # Отрисовка
            selection_screen.fill(WHITE)
            
            # Заголовок
            title_font = pygame.font.Font(None, 36)
            title = title_font.render("Выберите уровень для редактирования", True, BLACK)
            selection_screen.blit(title, (50, 10))
            
            # Кнопки категорий
            for category, name, rect in category_buttons:
                if category == selected_category and category in ["users", "main"]:
                    color = GREEN
                elif rect.collidepoint(pygame.mouse.get_pos()):
                    color = LIGHT_BLUE
                else:
                    color = LIGHT_GRAY
                
                pygame.draw.rect(selection_screen, color, rect)
                pygame.draw.rect(selection_screen, BLACK, rect, 2)
                
                category_text = self.font.render(name, True, BLACK)
                selection_screen.blit(category_text, (rect.x + 10, rect.y + 10))
            
            # Список уровней
            if levels:
                levels_title = self.font.render(f"Уровни в категории: {selected_category} ({len(levels)} шт.)", True, BLACK)
                selection_screen.blit(levels_title, (100, 170))
                
                for level, rect in level_buttons:
                    if rect.y < 200 or rect.y > 450:  # Пропускаем невидимые
                        continue
                        
                    color = LIGHT_BLUE if rect.collidepoint(pygame.mouse.get_pos()) else LIGHT_GRAY
                    pygame.draw.rect(selection_screen, color, rect)
                    pygame.draw.rect(selection_screen, BLACK, rect, 1)
                    
                    level_text = self.font.render(level, True, BLACK)
                    selection_screen.blit(level_text, (rect.x + 10, rect.y + 10))
            else:
                no_levels_text = self.font.render("В этой категории нет уровней", True, BLACK)
                selection_screen.blit(no_levels_text, (100, 200))
            
            # Инструкция
            instruction = self.small_font.render("Выберите категорию и уровень для редактирования", True, BLACK)
            selection_screen.blit(instruction, (50, selection_height - 30))
            
            pygame.display.flip()
        
        return None
    
    def toggle_display_mode(self):
        """Переключает режим отображения фигур"""
        if self.display_mode == DisplayMode.LETTERS:
            self.display_mode = DisplayMode.IMAGES if self.images_loaded else DisplayMode.UNICODE
        elif self.display_mode == DisplayMode.IMAGES:
            self.display_mode = DisplayMode.UNICODE
        else:
            self.display_mode = DisplayMode.LETTERS
        
    def create_ui_buttons(self):
        """Создает кнопки в нижней панели с правильным расположением"""
        panel_y = self.board_height + 5
        
        # Первый ряд: Инструменты (5 кнопок) - увеличены отступы
        tools = [
            (EditorTool.BLOCK, "Блоки"),
            (EditorTool.PLATFORM, "Платформы"), 
            (EditorTool.PLAYER_PIECE, "Синие фигуры"),
            (EditorTool.ENEMY_PIECE, "Красные фигуры"),
            (EditorTool.ERASER, "Ластик")
        ]
        
        self.tool_buttons = []
        button_width = 130  # Увеличили ширину кнопок
        for i, (tool, name) in enumerate(tools):
            x = 10 + i * (button_width + BUTTON_MARGIN)
            rect = pygame.Rect(x, panel_y, button_width, BUTTON_HEIGHT)
            self.tool_buttons.append((tool, name, rect))
        
        # Второй ряд: Типы фигур (6 кнопок) - увеличены отступы
        self.piece_buttons = []
        piece_types = list(PieceType)
        piece_button_width = 85
        for i, piece_type in enumerate(piece_types):
            x = 10 + i * (piece_button_width + BUTTON_MARGIN)
            rect = pygame.Rect(x, panel_y + 40, piece_button_width, BUTTON_HEIGHT)
            self.piece_buttons.append((piece_type, rect))
            
        # Третий ряд: Действия с файлами (3 кнопки) - увеличены отступы
        actions_row1 = [
            ("save", "Сохранить уровень", self.save_map),
            ("save_copy", "Сохранить копию", self.save_map_copy),
            ("open", "Открыть уровень", self.open_map),  
        ]
        
        self.action_buttons_row1 = []
        action_button_width = 150  # Увеличили ширину кнопок
        for i, (key, name, action) in enumerate(actions_row1):
            x = 10 + i * (action_button_width + BUTTON_MARGIN)
            rect = pygame.Rect(x, panel_y + 80, action_button_width, BUTTON_HEIGHT)
            self.action_buttons_row1.append((key, name, action, rect))
            
        # Четвертый ряд: Настройки (2 кнопки) - увеличены отступы
        actions_row2 = [
            ("category", f"Категория: {self.current_category}", self.toggle_category),
            ("display", f"Режим: {self.display_mode.value}", self.toggle_display_mode),
        ]
        
        self.action_buttons_row2 = []
        for i, (key, name, action) in enumerate(actions_row2):
            x = 10 + i * (action_button_width + BUTTON_MARGIN)
            rect = pygame.Rect(x, panel_y + 120, action_button_width, BUTTON_HEIGHT)
            self.action_buttons_row2.append((key, name, action, rect))
            
        # Пятый ряд: Размеры доски и очистка - увеличены отступы
        sizes = [("6x6", 6, 6), ("8x8", 8, 8), ("10x8", 10, 8), ("12x10", 12, 10), ("14x16", 14, 16)]
        self.size_buttons = []
        size_button_width = 90
        for i, (text, w, h) in enumerate(sizes):
            x = 10 + i * (size_button_width + BUTTON_MARGIN)
            rect = pygame.Rect(x, panel_y + 160, size_button_width, BUTTON_HEIGHT)
            self.size_buttons.append((text, w, h, rect))
            
        # Кнопка очистки
        self.clear_button = pygame.Rect(10 + 5 * (size_button_width + BUTTON_MARGIN), panel_y + 160, 120, BUTTON_HEIGHT)
        
    def update_ui_layout(self):
        """Обновляет расположение UI при изменении размера доски"""
        self.board_width = self.width * CELL_SIZE + 2 * MARGIN
        self.board_height = self.height * CELL_SIZE + 2 * MARGIN
        self.screen_width = max(1100, self.board_width)
        self.screen_height = self.board_height + UI_PANEL_HEIGHT
        
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        self.create_ui_buttons()
        
    def get_piece_at(self, x: int, y: int) -> Optional[Piece]:
        """Находит фигуру в указанной позиции"""
        for piece in self.pieces:
            if piece.x == x and piece.y == y:
                return piece
        return None
        
    def resize_board(self, width: int, height: int):
        """Изменяет размер доски"""
        self.width = width
        self.height = height
        
        # Удаляем элементы за пределами новой доски
        self.pieces = [p for p in self.pieces if 0 <= p.x < width and 0 <= p.y < height]
        self.blocks = {(x, y) for x, y in self.blocks if 0 <= x < width and 0 <= y < height}
        self.platforms = {(x, y) for x, y in self.platforms if 0 <= x < width and 0 <= y < height}
        
        self.update_ui_layout()
        
    def handle_board_click(self, cell_x: int, cell_y: int):
        """Обрабатывает клики по доске"""
        if self.current_tool == EditorTool.BLOCK:
            if (cell_x, cell_y) in self.blocks:
                self.blocks.remove((cell_x, cell_y))
            else:
                self.blocks.add((cell_x, cell_y))
                self.platforms.discard((cell_x, cell_y))
                
        elif self.current_tool == EditorTool.PLATFORM:
            if (cell_x, cell_y) in self.platforms:
                self.platforms.remove((cell_x, cell_y))
            else:
                self.platforms.add((cell_x, cell_y))
                self.blocks.discard((cell_x, cell_y))
                
        elif self.current_tool == EditorTool.PLAYER_PIECE:
            existing = self.get_piece_at(cell_x, cell_y)
            if existing:
                self.pieces.remove(existing)
            new_piece = Piece(self.current_piece_type, Player.PLAYER, cell_x, cell_y)
            self.pieces.append(new_piece)
            
        elif self.current_tool == EditorTool.ENEMY_PIECE:
            existing = self.get_piece_at(cell_x, cell_y)
            if existing:
                self.pieces.remove(existing)
            new_piece = Piece(self.current_piece_type, Player.ENEMY, cell_x, cell_y)
            self.pieces.append(new_piece)
            
        elif self.current_tool == EditorTool.ERASER:
            if (cell_x, cell_y) in self.blocks:
                self.blocks.remove((cell_x, cell_y))
            if (cell_x, cell_y) in self.platforms:
                self.platforms.remove((cell_x, cell_y))
            existing = self.get_piece_at(cell_x, cell_y)
            if existing:
                self.pieces.remove(existing)
                
    def handle_ui_click(self, mouse_x: int, mouse_y: int):
        """Обрабатывает клики по UI элементам"""
        # Инструменты
        for tool, name, rect in self.tool_buttons:
            if rect.collidepoint(mouse_x, mouse_y):
                self.current_tool = tool
                return
                
        # Типы фигур
        for piece_type, rect in self.piece_buttons:
            if rect.collidepoint(mouse_x, mouse_y):
                self.current_piece_type = piece_type
                return
                
        # Действия - первый ряд
        for key, name, action, rect in self.action_buttons_row1:
            if rect.collidepoint(mouse_x, mouse_y):
                action()
                return
                
        # Действия - второй ряд
        for key, name, action, rect in self.action_buttons_row2:
            if rect.collidepoint(mouse_x, mouse_y):
                action()
                # Обновляем текст кнопки после действия
                if key == "category":
                    for i, (k, n, a, r) in enumerate(self.action_buttons_row2):
                        if k == "category":
                            self.action_buttons_row2[i] = (k, f"Категория: {self.current_category}", a, r)
                elif key == "display":
                    for i, (k, n, a, r) in enumerate(self.action_buttons_row2):
                        if k == "display":
                            self.action_buttons_row2[i] = (k, f"Режим: {self.display_mode.value}", a, r)
                return
                
        # Размеры доски
        for text, w, h, rect in self.size_buttons:
            if rect.collidepoint(mouse_x, mouse_y):
                self.resize_board(w, h)
                return
                
        # Кнопка очистки
        if self.clear_button.collidepoint(mouse_x, mouse_y):
            self.clear_map()
            return
                
    def handle_click(self, pos: Tuple[int, int]):
        """Обрабатывает все клики мыши"""
        mouse_x, mouse_y = pos
        
        if mouse_y < self.board_height:
            board_offset_x = (self.screen_width - self.width * CELL_SIZE) // 2
            board_x = mouse_x - board_offset_x
            board_y = mouse_y - MARGIN
            
            if 0 <= board_x < self.width * CELL_SIZE and 0 <= board_y < self.height * CELL_SIZE:
                cell_x = board_x // CELL_SIZE
                cell_y = board_y // CELL_SIZE
                self.handle_board_click(cell_x, cell_y)
        else:
            self.handle_ui_click(mouse_x, mouse_y)
            
    def toggle_category(self):
        """Переключает категорию сохранения"""
        self.current_category = "main" if self.current_category == "users" else "users"
        self.current_filename = None  # Сбрасываем текущий файл при смене категории
            
    def save_map(self):
        """Сохраняет текущую карту с уникальным именем"""
        if self.current_filename:
            # Сохраняем в текущий файл
            filename = self.current_filename
        else:
            # Генерируем уникальное имя
            base_name = f"level_{self.width}x{self.height}"
            filename = self.generate_unique_filename(base_name, self.current_category)
            self.current_filename = filename
        
        base_path = "/storage/emulated/0/chesspython/levels"
        category_path = f"{base_path}/{self.current_category}"
        
        try:
            os.makedirs(category_path, exist_ok=True)
        except:
            base_path = "/data/data/ru.iiec.pydroid3/files"
            category_path = f"{base_path}/levels/{self.current_category}"
            os.makedirs(category_path, exist_ok=True)
        
        filepath = f"{category_path}/{filename}"
        
        map_data = {
            "board_size": [self.width, self.height],
            "blocks": list(self.blocks),
            "platforms": list(self.platforms),
            "pieces": [
                {
                    "type": piece.type.name.lower(),
                    "player": piece.player.value,
                    "position": [piece.x, piece.y]
                }
                for piece in self.pieces
            ]
        }
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(map_data, f, indent=2, ensure_ascii=False)
        except Exception:
            pass
    
    def save_map_copy(self):
        """Сохраняет копию карты с новым именем"""
        # Сбрасываем текущее имя файла, чтобы создать новую копию
        self.current_filename = None
        self.save_map()
    
    def open_map(self):
        """Открывает уровень для редактирования"""
        selected_level = self.show_level_selection()
        if selected_level:
            self.load_specific_map(selected_level)
    
    def load_specific_map(self, filename: str):
        """Загружает конкретный файл уровня"""
        # Пробуем загрузить из разных мест
        paths_to_try = [
            f"/storage/emulated/0/chesspython/levels/{self.current_category}/{filename}",
            f"/data/data/ru.iiec.pydroid3/files/levels/{self.current_category}/{filename}",
        ]
        
        loaded = False
        for filepath in paths_to_try:
            try:
                if os.path.exists(filepath):
                    with open(filepath, 'r', encoding='utf-8') as f:
                        map_data = json.load(f)
                        
                    new_width, new_height = map_data["board_size"]
                    if (new_width, new_height) != (self.width, self.height):
                        self.resize_board(new_width, new_height)
                    
                    self.blocks = set(tuple(pos) for pos in map_data.get("blocks", []))
                    self.platforms = set(tuple(pos) for pos in map_data.get("platforms", []))
                    
                    self.pieces = []
                    for piece_data in map_data["pieces"]:
                        piece_type = PieceType[piece_data["type"].upper()]
                        player = Player(piece_data["player"])
                        x, y = piece_data["position"]
                        self.pieces.append(Piece(piece_type, player, x, y))
                    
                    self.current_filename = filename
                    loaded = True
                    break
            except Exception:
                continue
        
    def clear_map(self):
        """Очищает все элементы карты"""
        self.pieces.clear()
        self.blocks.clear()
        self.platforms.clear()
        
    def draw_button(self, text: str, x: int, y: int, width: int, height: int, active: bool = False, color: tuple = None):
        """Рисует кнопку"""
        if color is None:
            color = GREEN if active else LIGHT_GRAY
        
        rect = pygame.Rect(x, y, width, height)
        pygame.draw.rect(self.screen, color, rect)
        pygame.draw.rect(self.screen, BLACK, rect, 1)
        
        font = self.small_font if len(text) > 15 else self.font
        text_surface = font.render(text, True, BLACK)
        text_rect = text_surface.get_rect(center=rect.center)
        self.screen.blit(text_surface, text_rect)
        
    def draw_board(self):
        """Рисует игровую доску"""
        board_offset_x = (self.screen_width - self.width * CELL_SIZE) // 2
        
        board_rect = pygame.Rect(
            board_offset_x - 2, 
            MARGIN - 2, 
            self.width * CELL_SIZE + 4, 
            self.height * CELL_SIZE + 4
        )
        pygame.draw.rect(self.screen, BLACK, board_rect, 2)
        
        for y in range(self.height):
            for x in range(self.width):
                rect = pygame.Rect(
                    board_offset_x + x * CELL_SIZE,
                    MARGIN + y * CELL_SIZE,
                    CELL_SIZE, CELL_SIZE
                )
                
                color = BROWN1 if (x + y) % 2 == 0 else BROWN2
                pygame.draw.rect(self.screen, color, rect)
                
                if (x, y) in self.blocks:
                    pygame.draw.rect(self.screen, GRAY, rect)
                    
                if (x, y) in self.platforms:
                    platform_height = CELL_SIZE // 8
                    platform_rect = pygame.Rect(rect.x, rect.y, CELL_SIZE, platform_height)
                    pygame.draw.rect(self.screen, PLATFORM_COLOR, platform_rect)
                    pygame.draw.rect(self.screen, BLACK, platform_rect, 1)
                    
                pygame.draw.rect(self.screen, BLACK, rect, 1)
        
    def draw_pieces(self):
        """Рисует фигуры в выбранном режиме отображения"""
        board_offset_x = (self.screen_width - self.width * CELL_SIZE) // 2
        
        # Символы для режима букв
        letter_abbreviations = {
            PieceType.KING: "K", PieceType.QUEEN: "Q", PieceType.ROOK: "R", 
            PieceType.BISHOP: "B", PieceType.KNIGHT: "N", PieceType.PAWN: "P"
        }
        
        # Символы для режима юникода
        unicode_symbols = {
            (PieceType.KING, Player.PLAYER): "♔", (PieceType.QUEEN, Player.PLAYER): "♕", 
            (PieceType.ROOK, Player.PLAYER): "♖", (PieceType.BISHOP, Player.PLAYER): "♗", 
            (PieceType.KNIGHT, Player.PLAYER): "♘", (PieceType.PAWN, Player.PLAYER): "♙",
            (PieceType.KING, Player.ENEMY): "♚", (PieceType.QUEEN, Player.ENEMY): "♛", 
            (PieceType.ROOK, Player.ENEMY): "♜", (PieceType.BISHOP, Player.ENEMY): "♝", 
            (PieceType.KNIGHT, Player.ENEMY): "♞", (PieceType.PAWN, Player.ENEMY): "♟"
        }
        
        for piece in self.pieces:
            x = board_offset_x + piece.x * CELL_SIZE
            y = MARGIN + piece.y * CELL_SIZE
            
            if self.display_mode == DisplayMode.IMAGES and self.images_loaded:
                image_key = f"{piece.type.name.lower()}_{'white' if piece.player == Player.PLAYER else 'black'}"
                if image_key in self.piece_images:
                    img_rect = self.piece_images[image_key].get_rect(center=(x + CELL_SIZE//2, y + CELL_SIZE//2))
                    self.screen.blit(self.piece_images[image_key], img_rect)
                    continue
            
            font = pygame.font.Font(None, 40)
            color = BLUE if piece.player == Player.PLAYER else RED
            
            if self.display_mode == DisplayMode.UNICODE:
                text_str = unicode_symbols.get((piece.type, piece.player), "?")
            else:
                text_str = letter_abbreviations.get(piece.type, "?")
                
            text = font.render(text_str, True, color)
            text_rect = text.get_rect(center=(x + CELL_SIZE//2, y + CELL_SIZE//2))
            self.screen.blit(text, text_rect)
            
    def draw_ui_panel(self):
        """Рисует нижнюю панель с кнопками"""
        panel_y = self.board_height
        panel_rect = pygame.Rect(0, panel_y, self.screen_width, UI_PANEL_HEIGHT)
        pygame.draw.rect(self.screen, WHITE, panel_rect)
        pygame.draw.rect(self.screen, BLACK, panel_rect, 2)
        
        # Заголовки строк
        labels_x = 5
        self.screen.blit(self.font.render("Инструменты:", True, BLACK), (labels_x, panel_y + 5))
        self.screen.blit(self.font.render("Типы фигур:", True, BLACK), (labels_x, panel_y + 45))
        self.screen.blit(self.font.render("Файлы:", True, BLACK), (labels_x, panel_y + 85))
        self.screen.blit(self.font.render("Настройки:", True, BLACK), (labels_x, panel_y + 125))
        self.screen.blit(self.font.render("Размеры доски:", True, BLACK), (labels_x, panel_y + 165))
        
        # Кнопки инструментов
        for tool, name, rect in self.tool_buttons:
            active = (self.current_tool == tool)
            color = GREEN if active else LIGHT_GRAY
            self.draw_button(name, rect.x, rect.y, rect.width, rect.height, active, color)
            
        # Кнопки типов фигур
        for piece_type, rect in self.piece_buttons:
            active = (self.current_piece_type == piece_type)
            self.draw_button(piece_type.value, rect.x, rect.y, rect.width, rect.height, active)
            
        # Кнопки действий - первый ряд (файлы)
        for key, name, action, rect in self.action_buttons_row1:
            color = LIGHT_BLUE
            self.draw_button(name, rect.x, rect.y, rect.width, rect.height, False, color)
            
        # Кнопки действий - второй ряд
        for key, name, action, rect in self.action_buttons_row2:
            if key == "category":
                color = GOLD
            elif key == "display":
                color = PURPLE
            else:
                color = LIGHT_BLUE
            self.draw_button(name, rect.x, rect.y, rect.width, rect.height, False, color)
            
        # Кнопки размеров
        for text, w, h, rect in self.size_buttons:
            active = (self.width, self.height) == (w, h)
            self.draw_button(text, rect.x, rect.y, rect.width, rect.height, active)
            
        # Кнопка очистки
        self.draw_button("Очистить доску", self.clear_button.x, self.clear_button.y, 
                        self.clear_button.width, self.clear_button.height, False, RED)
            
        # Информация о текущем состоянии
        current_file = self.current_filename if self.current_filename else "Новый уровень"
        info_text = f"Файл: {current_file} | Доска: {self.width}x{self.height} | Инструмент: {self.current_tool.value} | Фигура: {self.current_piece_type.value}"
        info_surface = self.small_font.render(info_text, True, BLACK)
        self.screen.blit(info_surface, (10, panel_y + 185))
        
    def draw(self):
        """Основной метод отрисовки"""
        self.screen.fill(WHITE)
        
        self.draw_board()
        self.draw_pieces()
        self.draw_ui_panel()
        
        pygame.display.flip()
        
    def run(self):
        """Основной цикл редактора"""
        clock = pygame.time.Clock()
        running = True
        
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        self.handle_click(event.pos)
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False
                        
            self.draw()
            clock.tick(60)
            
        pygame.quit()
        sys.exit()

def main():
    editor = MapEditor()
    editor.run()

if __name__ == "__main__":
    main()