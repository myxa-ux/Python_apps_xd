import pygame, sys, json, os
from enum import Enum

pygame.init()
CELL_SIZE, MARGIN = 60, 50
WHITE,BLACK = (255, 255, 255), (0, 0, 0)
BROWN1, BROWN2 = (240, 217, 181), (181,136, 99)
BLUE, RED, GREEN, GRAY, GOLD = (0, 100, 200), (200, 0, 0), (0, 200, 0), (64, 64, 64), (15, 95, 0)
LIGHT_BLUE, PURPLE = (100, 100, 255), (150, 100, 200)
PLATFORM_COLOR = (139, 69, 19)

class PieceType(Enum):
    KING, QUEEN, ROOK, BISHOP, KNIGHT, PAWN = "♔", "♕", "♖", "♗", "♘", "♙"

class Player(Enum):
    PLAYER, ENEMY = "player", "enemy"

class DisplayMode(Enum):
    LETTERS, IMAGES, UNICODE = "letters", "images", "unicode"

class Piece:
    def __init__(self, piece_type, player, x, y):
        self.type, self.player, self.x, self.y = piece_type, player, x, y

class LevelManager:
    def __init__(self):
        self.base_path = "/storage/emulated/0/chesspython/levels"
        self.users_path = f"{self.base_path}/users"
        self.main_path = f"{self.base_path}/main"
        self.progress_file = f"{self.base_path}/progress.json"
        self.level_structure = {}
        self.load_progress()
        self.build_level_structure()
    
    def build_level_structure(self):
        try:
            main_levels = self.get_level_files("main")
            if main_levels:
                self.level_structure = {}
                queue = [main_levels[0]]
                index = 1
                
                while queue and index < len(main_levels):
                    current = queue.pop(0)
                    children = []
                    for _ in range(2):
                        if index < len(main_levels):
                            children.append(main_levels[index])
                            index += 1
                    self.level_structure[current] = children
                    queue.extend(children)
        except Exception as e:
            print(f"Ошибка построения структуры уровней: {e}")
    
    def get_unlocked_levels(self, category: str) -> list:
        if category == "users":
            return self.get_level_files(category)
        
        unlocked = []
        main_levels = self.get_level_files("main")
        
        if not main_levels:
            return unlocked
        
        unlocked.append(main_levels[0])
        
        for level, children in self.level_structure.items():
            if self.is_level_completed("main", level):
                unlocked.extend(children)
        
        return [level for level in main_levels if level in unlocked]
    
    def get_level_files(self, category: str) -> list:
        system_path = self.main_path if category == "main" else self.users_path
        local_path = f"/app/levels/{category}"
        levels = []
        for path in [system_path, local_path]:
            try:
                if os.path.exists(path):
                    files = [f for f in os.listdir(path) if f.endswith('.json')]
                    levels.extend([f for f in files if f not in levels])
            except: continue
        return sorted(levels)
    
    def load_progress(self):
        try:
            if os.path.exists(self.progress_file):
                with open(self.progress_file, 'r', encoding='utf-8') as f:
                    self.progress = json.load(f)
            else: 
                self.progress = {"main": {}, "users": {}}
        except: 
            self.progress = {"main": {}, "users": {}}
    
    def save_progress(self):
        try:
            os.makedirs(os.path.dirname(self.progress_file), exist_ok=True)
            with open(self.progress_file, 'w', encoding='utf-8') as f:
                json.dump(self.progress, f, ensure_ascii=False, indent=2)
        except: pass
    
    def mark_level_completed(self, category: str, level_name: str):
        if category not in self.progress: 
            self.progress[category] = {}
        self.progress[category][level_name] = True
        self.save_progress()
    
    def is_level_completed(self, category: str, level_name: str) -> bool:
        return self.progress.get(category, {}).get(level_name, False)
    
    def get_levels(self, category: str) -> list:
        return self.get_level_files(category)
    
    def get_level_path(self, category: str, level_name: str) -> str:
        base = self.main_path if category == "main" else self.users_path
        return f"{base}/{level_name}"

class Game:
    def __init__(self):
        self.width, self.height = 8, 8
        self.pieces = [
            Piece(PieceType.ROOK, Player.PLAYER, 1, 6), Piece(PieceType.QUEEN, Player.PLAYER, 2, 6),
            Piece(PieceType.KING, Player.PLAYER, 3, 6), Piece(PieceType.KING, Player.ENEMY, 5, 4),
            Piece(PieceType.KNIGHT, Player.ENEMY, 6, 4), Piece(PieceType.ROOK, Player.ENEMY, 7, 2)
        ]
        self.blocks = {(1, 7), (2, 7), (5, 5), (6, 5), (0, 0), (7, 0)}
        self.platforms = set(); self.selected = None
        self.level_manager = LevelManager(); self.current_category = self.current_level = None
        self.current_level_index = 0; self.available_levels = []
        self.board_width = MARGIN * 2 + self.width * CELL_SIZE
        self.board_height = MARGIN * 2 + self.height * CELL_SIZE
        self.window_height = self.board_height + 200
        self.screen = pygame.display.set_mode((self.board_width, self.window_height))
        pygame.display.set_caption("Gravity Chess")
        self.piece_images, self.images_loaded = {}, False
        self.game_won = self.game_lost = self.show_message = False
        self.load_piece_images()
        
        if self.images_loaded:
            self.display_mode = DisplayMode.IMAGES
        else:
            self.display_mode = DisplayMode.LETTERS
            
        self.apply_gravity()
        self.board_bottom = MARGIN + self.height * CELL_SIZE; self.create_buttons()
        self.show_debug_info = False
        
    def create_buttons(self):
        total_width = self.board_width - 40
        button_width = total_width // 3 - 10
        button_height = 50
        
        base_y = self.board_bottom + 60
        
        self.button_restart = pygame.Rect(10, base_y, button_width, button_height)
        self.button_next = pygame.Rect(20 + button_width, base_y, button_width, button_height)
        self.button_display_mode = pygame.Rect(30 + button_width * 2, base_y, button_width, button_height)
        
        self.button_levels = pygame.Rect(10, base_y + 60, button_width, button_height)
        self.button_categories = pygame.Rect(20 + button_width, base_y + 60, button_width, button_height)
        self.button_exit = pygame.Rect(30 + button_width * 2, base_y + 60, button_width, button_height)
        
        self.button_debug = pygame.Rect(10, base_y + 120, button_width, button_height)
        self.button_skip = pygame.Rect(20 + button_width, base_y + 120, button_width, button_height)
        
    def get_piece_at(self, x, y):
        return next((p for p in self.pieces if p.x == x and p.y == y), None)
        
    def load_piece_images(self):
        base_path = "/storage/emulated/0/chesspython/chess_images"
        piece_files = {
            'king_white': 'king_blue.jpg', 'queen_white': 'queen_blue.jpg', 'rook_white': 'rook_blue.jpg',
            'bishop_white': 'bishop_blue.jpg', 'knight_white': 'knight_blue.jpg', 'pawn_white': 'pawn_blue.jpg',
            'king_black': 'red.jpg', 'queen_black': 'red.jpg', 'rook_black': 'red.jpg',
            'bishop_black': 'red.jpg', 'knight_black': 'red.jpg', 'pawn_black': 'red.jpg'
        }
        
        self.debug_info = []
        self.debug_info.append(f"Проверяем путь: {base_path}")
        self.debug_info.append(f"Путь существует: {os.path.exists(base_path)}")
        
        try:
            if not os.path.exists(base_path): 
                self.debug_info.append("Создаем папку...")
                os.makedirs(base_path)
                self.images_loaded = False
                return
            
            files_in_folder = os.listdir(base_path)
            self.debug_info.append(f"Файлы в папке: {', '.join(files_in_folder)}")
            
            missing_files = []
            for file in piece_files.values():
                file_path = os.path.join(base_path, file)
                if not os.path.exists(file_path):
                    missing_files.append(file)
                    self.debug_info.append(f"Отсутствует: {file}")
            
            if missing_files:
                self.debug_info.append(f"Отсутствуют файлы: {missing_files}")
                self.images_loaded = False
                return
            
            loaded_count = 0
            for name, file in piece_files.items():
                try:
                    file_path = os.path.join(base_path, file)
                    img = pygame.image.load(file_path)
                    self.piece_images[name] = pygame.transform.scale(img, (CELL_SIZE-10, CELL_SIZE-10))
                    loaded_count += 1
                except Exception as e:
                    self.debug_info.append(f"Ошибка загрузки {file}: {str(e)}")
            
            self.images_loaded = (loaded_count == len(piece_files))
            self.debug_info.append(f"Загружено: {loaded_count}/{len(piece_files)}")
            self.debug_info.append(f"Режим изображений: {self.images_loaded}")
            
        except Exception as e:
            self.debug_info.append(f"Общая ошибка: {str(e)}")
            self.images_loaded = False

    def apply_gravity(self):
        max_iterations, iterations = 10, 0
        while iterations < max_iterations:
            changed = False; iterations += 1
            for piece in sorted(self.pieces, key=lambda p: p.y, reverse=True):
                target_y = piece.y
                while target_y + 1 < self.height:
                    if (piece.x, target_y + 1) in self.blocks: break
                    if self.get_piece_at(piece.x, target_y + 1): break
                    if (piece.x, target_y + 1) in self.platforms: break
                    target_y += 1
                if target_y != piece.y: piece.y = target_y; changed = True
            if not changed: break
    
    def get_moves(self, piece):
        if piece.player != Player.PLAYER: return []
        moves = []
        directions = {
            PieceType.ROOK: [(0,1), (0,-1), (1,0), (-1,0)],
            PieceType.QUEEN: [(0,1), (0,-1), (1,0), (-1,0), (1,1), (1,-1), (-1,1), (-1,-1)],
            PieceType.KING: [(0,1), (0,-1), (1,0), (-1,0), (1,1), (1,-1), (-1,1), (-1,-1)],
            PieceType.KNIGHT: [(2,1), (2,-1), (-2,1), (-2,-1), (1,2), (1,-2), (-1,2), (-1,-2)],
            PieceType.BISHOP: [(1,1), (1,-1), (-1,1), (-1,-1)],
            PieceType.PAWN: [(-1,-1), (1,-1)]
        }.get(piece.type, [])
        
        for dx, dy in directions:
            if piece.type in [PieceType.KING, PieceType.KNIGHT, PieceType.PAWN]:
                nx, ny = piece.x + dx, piece.y + dy
                if 0 <= nx < self.width and 0 <= ny < self.height and (nx, ny) not in self.blocks:
                    target = self.get_piece_at(nx, ny)
                    if not target or target.player != piece.player: moves.append((nx, ny))
            else:
                for i in range(1, 16):
                    nx, ny = piece.x + dx*i, piece.y + dy*i
                    if not (0 <= nx < self.width and 0 <= ny < self.height) or (nx, ny) in self.blocks: break
                    target = self.get_piece_at(nx, ny)
                    if target:
                        if target.player != piece.player: moves.append((nx, ny))
                        break
                    moves.append((nx, ny))
        return moves
        
    def move_piece(self, piece, nx, ny):
        if captured := self.get_piece_at(nx, ny): self.pieces.remove(captured)
        piece.x, piece.y = nx, ny
        self.apply_gravity()
        
        if not (self.game_won or self.game_lost):
            self.check_game_over()
    
    def check_game_over(self):
        player_pieces = [p for p in self.pieces if p.player == Player.PLAYER]
        enemy_pieces = [p for p in self.pieces if p.player == Player.ENEMY]
        if not enemy_pieces: 
            self.game_won = self.show_message = True
            if self.current_category and self.current_level:
                self.level_manager.mark_level_completed(self.current_category, self.current_level)
        elif not player_pieces: 
            self.game_lost = self.show_message = True
    
    def load_custom_map(self, category: str, filename: str):
        try:
            system_filepath = self.level_manager.get_level_path(category, filename)
            local_filepath = f"/app/levels/{category}/{filename}"
            filepath = system_filepath if os.path.exists(system_filepath) else local_filepath
            with open(filepath, 'r', encoding='utf-8') as f: map_data = json.load(f)
            self.width, self.height = map_data["board_size"]
            self.blocks = set(tuple(pos) for pos in map_data.get("blocks", []))
            self.platforms = set(tuple(pos) for pos in map_data.get("platforms", []))
            self.pieces = [Piece(PieceType[piece_data["type"].upper()], Player(piece_data["player"]), *piece_data["position"]) for piece_data in map_data["pieces"]]
            self.game_won = self.game_lost = self.show_message = False
            self.selected = None  # Сбрасываем выделение при загрузке нового уровня
            self.current_category, self.current_level = category, filename
            self.board_width = MARGIN * 2 + self.width * CELL_SIZE
            self.board_height = MARGIN * 2 + self.height * CELL_SIZE
            self.window_height = self.board_height + 200
            self.screen = pygame.display.set_mode((self.board_width, self.window_height))
            self.board_bottom = MARGIN + self.height * CELL_SIZE; self.create_buttons(); self.apply_gravity()
            return True
        except: return False
    
    def show_category_selection(self):
        menu_screen = pygame.display.set_mode((600, 400))
        buttons = [
            {"text": "Основная компания", "category": "main", "rect": pygame.Rect(150, 120, 300, 60)},
            {"text": "Пользовательские уровни", "category": "users", "rect": pygame.Rect(150, 200, 300, 60)},
            {"text": "Стандартный уровень", "category": None, "rect": pygame.Rect(150, 280, 300, 60)}
        ]
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT: return None
                if event.type == pygame.MOUSEBUTTONDOWN:
                    pos = pygame.mouse.get_pos()
                    for button in buttons:
                        if button["rect"].collidepoint(pos): return button["category"]
            menu_screen.fill(WHITE)
            font, small_font = pygame.font.Font(None, 36), pygame.font.Font(None, 28)
            menu_screen.blit(font.render("ВЫБЕРИТЕ КАТЕГОРИЮ", True, BLACK), (150, 50))
            for button in buttons:
                color = BLUE if button["rect"].collidepoint(pygame.mouse.get_pos()) else LIGHT_BLUE
                pygame.draw.rect(menu_screen, color, button["rect"])
                pygame.draw.rect(menu_screen, BLACK, button["rect"], 2)
                text = small_font.render(button["text"], True, WHITE)
                menu_screen.blit(text, text.get_rect(center=button["rect"].center))
            pygame.display.flip()
    
    def show_level_selection(self, category: str):
        if category == "main":
            levels = self.level_manager.get_unlocked_levels(category)
        else:
            levels = self.level_manager.get_levels(category)
            
        if not levels: return None
        menu_screen = pygame.display.set_mode((700, 600))
        buttons = []
        for i, level in enumerate(levels):
            is_completed = self.level_manager.is_level_completed(category, level)
            is_unlocked = level in self.level_manager.get_unlocked_levels(category) if category == "main" else True
            color = GREEN if is_completed else (LIGHT_BLUE if is_unlocked else GRAY)
            buttons.append({
                "text": level.replace('.json', ''), 
                "level": level, 
                "completed": is_completed, 
                "unlocked": is_unlocked,
                "color": color, 
                "rect": pygame.Rect(50, 100 + i*60, 600, 50)
            })
        scroll_offset, max_scroll = 0, max(0, len(buttons) * 60 - 400)
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT: return None
                if event.type == pygame.MOUSEBUTTONDOWN:
                    pos = pygame.mouse.get_pos()
                    for button in buttons:
                        adjusted_rect = pygame.Rect(button["rect"].x, button["rect"].y - scroll_offset, button["rect"].width, button["rect"].height)
                        if adjusted_rect.collidepoint(pos) and adjusted_rect.y >= 100 and button["unlocked"]:
                            self.available_levels, self.current_level_index = levels, levels.index(button["level"])
                            return button["level"]
                elif event.type == pygame.MOUSEWHEEL:
                    scroll_offset = max(0, min(max_scroll, scroll_offset - event.y * 30))
            menu_screen.fill(WHITE)
            font, small_font = pygame.font.Font(None, 36), pygame.font.Font(None, 24)
            category_name = "Основная компания" if category == "main" else "Пользовательские уровни"
            menu_screen.blit(font.render(f"УРОВНИ: {category_name.upper()}", True, BLACK), (50, 30))
            for button in buttons:
                adjusted_y = button["rect"].y - scroll_offset
                if adjusted_y > -60 and adjusted_y < 600:
                    rect = pygame.Rect(button["rect"].x, adjusted_y, button["rect"].width, button["rect"].height)
                    color = button["color"]
                    if rect.collidepoint(pygame.mouse.get_pos()) and button["unlocked"]:
                        color = GOLD if button["completed"] else BLUE
                    pygame.draw.rect(menu_screen, color, rect); pygame.draw.rect(menu_screen, BLACK, rect, 2)
                    text_color = WHITE if not button["completed"] and button["unlocked"] else (BLACK if button["unlocked"] else (100, 100, 100))
                    text = small_font.render(button["text"], True, text_color)
                    menu_screen.blit(text, text.get_rect(center=rect.center))
                    if button["completed"]:
                        checkmark = small_font.render("✓", True, BLACK)
                        menu_screen.blit(checkmark, (rect.right - 30, rect.y + 15))
                    if not button["unlocked"]:
                        lock = small_font.render("🔒", True, BLACK)
                        menu_screen.blit(lock, (rect.right - 30, rect.y + 15))
            instruction = small_font.render("пройдите уровни для открытия других(компания)", True, BLACK)
            menu_screen.blit(instruction, (650, 600)); pygame.display.flip()

    def load_next_level(self):
        if not self.current_category or not self.available_levels: return False
        
        if self.current_category == "main":
            unlocked_levels = self.level_manager.get_unlocked_levels(self.current_category)
            next_index = self.current_level_index + 1
            if next_index < len(self.available_levels):
                next_level = self.available_levels[next_index]
                if next_level in unlocked_levels:
                    if self.load_custom_map(self.current_category, next_level):
                        self.current_level_index = next_index
                        return True
            return False
        else:
            next_index = self.current_level_index + 1
            if next_index < len(self.available_levels):
                next_level = self.available_levels[next_index]
                if self.load_custom_map(self.current_category, next_level):
                    self.current_level_index = next_index
                    return True
            return False

    def skip_level(self):
        """Пропуск уровня - переход к следующему, если он доступен"""
        if not self.current_category or not self.available_levels: return False
        
        if self.current_category == "main":
            # В основной компании можно пропускать только разблокированные уровни
            unlocked_levels = self.level_manager.get_unlocked_levels(self.current_category)
            next_index = self.current_level_index + 1
            if next_index < len(self.available_levels):
                next_level = self.available_levels[next_index]
                if next_level in unlocked_levels:
                    if self.load_custom_map(self.current_category, next_level):
                        self.current_level_index = next_index
                        return True
            return False
        else:
            # В пользовательских уровнях можно пропускать любой уровень
            next_index = self.current_level_index + 1
            if next_index < len(self.available_levels):
                next_level = self.available_levels[next_index]
                if self.load_custom_map(self.current_category, next_level):
                    self.current_level_index = next_index
                    return True
            return False

    def toggle_display_mode(self):
        if self.display_mode == DisplayMode.LETTERS: 
            self.display_mode = DisplayMode.IMAGES if self.images_loaded else DisplayMode.UNICODE
        elif self.display_mode == DisplayMode.IMAGES: 
            self.display_mode = DisplayMode.UNICODE
        else: 
            self.display_mode = DisplayMode.LETTERS
        
    def handle_click(self, pos):
        if pos[1] > self.board_bottom:
            if self.button_restart.collidepoint(pos):
                if self.current_category and self.current_level: 
                    self.load_custom_map(self.current_category, self.current_level)
                else: 
                    self.__init__()
            elif self.button_exit.collidepoint(pos): 
                pygame.quit(); sys.exit()
            elif self.button_next.collidepoint(pos):
                if self.game_won and self.current_category:
                    self.load_next_level()
                else:
                    self.show_message = False
            elif self.button_skip.collidepoint(pos):
                # Пропуск уровня - работает всегда, но с проверкой доступности
                self.skip_level()
            elif self.button_categories.collidepoint(pos):
                selected_category = self.show_category_selection()
                if selected_category is not None:
                    if selected_category:
                        selected_level = self.show_level_selection(selected_category)
                        if selected_level: 
                            self.load_custom_map(selected_category, selected_level)
                    else: 
                        self.__init__()
            elif self.button_levels.collidepoint(pos):
                if self.current_category:
                    selected_level = self.show_level_selection(self.current_category)
                    if selected_level: 
                        self.load_custom_map(self.current_category, selected_level)
                else:
                    selected_category = self.show_category_selection()
                    if selected_category:
                        selected_level = self.show_level_selection(selected_category)
                        if selected_level: 
                            self.load_custom_map(selected_category, selected_level)
            elif self.button_display_mode.collidepoint(pos): 
                self.toggle_display_mode()
            elif self.button_debug.collidepoint(pos):
                self.show_debug_info = not self.show_debug_info
            return
            
        mx, my = pos
        if MARGIN <= mx < MARGIN + self.width * CELL_SIZE and MARGIN <= my < MARGIN + self.height * CELL_SIZE:
            cx, cy = (mx - MARGIN) // CELL_SIZE, (my - MARGIN) // CELL_SIZE
            
            # Отмена выделения при повторном нажатии на выбранную фигуру
            if self.selected and self.selected.x == cx and self.selected.y == cy:
                self.selected = None
                return
                
            if self.selected:
                if (cx, cy) in self.get_moves(self.selected):
                    self.move_piece(self.selected, cx, cy)
                    # Фигура остается выделенной после хода ("память" на фигуры)
                elif piece := self.get_piece_at(cx, cy):
                    if piece.player == Player.PLAYER:
                        self.selected = piece
            else:
                if piece := self.get_piece_at(cx, cy):
                    if piece.player == Player.PLAYER:
                        self.selected = piece
    
    def draw(self):
        self.screen.fill(WHITE)
        for y in range(self.height):
            for x in range(self.width):
                rect = pygame.Rect(MARGIN + x*CELL_SIZE, MARGIN + y*CELL_SIZE, CELL_SIZE, CELL_SIZE)
                pygame.draw.rect(self.screen, BROWN1 if (x+y)%2==0 else BROWN2, rect)
                if (x, y) in self.blocks: pygame.draw.rect(self.screen, GRAY, rect)
                if (x, y) in self.platforms:
                    platform_rect = pygame.Rect(rect.x, rect.y, CELL_SIZE, CELL_SIZE // 8)
                    pygame.draw.rect(self.screen, PLATFORM_COLOR, platform_rect); pygame.draw.rect(self.screen, BLACK, platform_rect, 1)
                if self.selected and self.selected.x == x and self.selected.y == y: pygame.draw.rect(self.screen, GREEN, rect, 3)
                if self.selected and (x, y) in self.get_moves(self.selected): 
                    pygame.draw.circle(self.screen, GREEN, rect.center, 10)
                pygame.draw.rect(self.screen, BLACK, rect, 1)
        self.draw_pieces()
        if (self.game_won or self.game_lost) and self.show_message: 
            self.draw_game_over_message()
        self.draw_buttons()
        if self.show_debug_info:
            self.draw_debug_info()
        pygame.display.flip()
    
    def draw_pieces(self):
        letter_abbreviations = {PieceType.KING: "K", PieceType.QUEEN: "Q", PieceType.ROOK: "R", PieceType.BISHOP: "B", PieceType.KNIGHT: "N", PieceType.PAWN: "P"}
        unicode_symbols = {
            (PieceType.KING, Player.PLAYER): "♔", (PieceType.QUEEN, Player.PLAYER): "♕", (PieceType.ROOK, Player.PLAYER): "♖", 
            (PieceType.BISHOP, Player.PLAYER): "♗", (PieceType.KNIGHT, Player.PLAYER): "♘", (PieceType.PAWN, Player.PLAYER): "♙",
            (PieceType.KING, Player.ENEMY): "♚", (PieceType.QUEEN, Player.ENEMY): "♛", (PieceType.ROOK, Player.ENEMY): "♜", 
            (PieceType.BISHOP, Player.ENEMY): "♝", (PieceType.KNIGHT, Player.ENEMY): "♞", (PieceType.PAWN, Player.ENEMY): "♟"
        }
        for piece in self.pieces:
            x, y = MARGIN + piece.x * CELL_SIZE, MARGIN + piece.y * CELL_SIZE
            
            if self.display_mode == DisplayMode.IMAGES and self.images_loaded:
                image_key = f"{piece.type.name.lower()}_{'white' if piece.player == Player.PLAYER else 'black'}"
                if image_key in self.piece_images:
                    img_rect = self.piece_images[image_key].get_rect(center=(x + CELL_SIZE//2, y + CELL_SIZE//2))
                    self.screen.blit(self.piece_images[image_key], img_rect)
                    continue
            
            font = pygame.font.Font(None, 40); color = BLUE if piece.player == Player.PLAYER else RED
            if self.display_mode == DisplayMode.UNICODE: text_str = unicode_symbols.get((piece.type, piece.player), "?")
            else: text_str = letter_abbreviations.get(piece.type, "?")
            text = font.render(text_str, True, color)
            self.screen.blit(text, text.get_rect(center=(x + CELL_SIZE//2, y + CELL_SIZE//2)))
    
    def draw_game_over_message(self):
        panel_width = min(500, self.board_width - 100)
        panel = pygame.Surface((panel_width, 60), pygame.SRCALPHA); panel.fill((0, 0, 0, 180))
        panel_rect = panel.get_rect(center=(self.board_width // 2, self.board_bottom + 30))
        self.screen.blit(panel, panel_rect)
        font = pygame.font.Font(None, 48)
        text = font.render("пройдено" if self.game_won else "как?", True, GOLD if self.game_won else RED)
        text_rect = text.get_rect(center=(self.board_width // 2, self.board_bottom + 30))
        self.screen.blit(text, text_rect)
    
    def draw_buttons(self):
        buttons = [
            (self.button_restart, (200,20,0), "Перезапуск"), 
            (self.button_next, BLUE, "Дальше"),
            (self.button_display_mode, PURPLE, f"Режим: {self.display_mode.value}"), 
            (self.button_levels, LIGHT_BLUE, "Уровни"),
            (self.button_categories, GOLD, "Категории"), 
            (self.button_exit, RED, "Выход"),
            (self.button_debug, GRAY, "Отладка" if not self.show_debug_info else "Скрыть отладку"),
            (self.button_skip, (255, 165, 0), "Пропуск")  # Оранжевая кнопка пропуска
        ]
        font = pygame.font.Font(None, 20)
        for button_rect, color, text in buttons:
            pygame.draw.rect(self.screen, color, button_rect); pygame.draw.rect(self.screen, BLACK, button_rect, 2)
            text_surface = font.render(text, True, WHITE); text_rect = text_surface.get_rect(center=button_rect.center)
            self.screen.blit(text_surface, text_rect)
    
    def draw_debug_info(self):
        font = pygame.font.Font(None, 20)
        y_offset = self.board_bottom + 180
        
        debug_lines = self.debug_info[-5:] if hasattr(self, 'debug_info') else ["Нет отладочной информации"]
        
        for i, line in enumerate(debug_lines):
            text_surface = font.render(line, True, BLACK)
            self.screen.blit(text_surface, (10, y_offset + i*20))
    
    def run(self):
        clock = pygame.time.Clock(); running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT: running = False
                elif event.type == pygame.MOUSEBUTTONDOWN: self.handle_click(event.pos)
            self.draw(); clock.tick(60)
        pygame.quit(); sys.exit()

def main():
    game = Game()
    selected_category = game.show_category_selection()
    if selected_category is not None:
        if selected_category:
            selected_level = game.show_level_selection(selected_category)
            if selected_level: game.load_custom_map(selected_category, selected_level)
    game.run()

if __name__ == "__main__":
    main()